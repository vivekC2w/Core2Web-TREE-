

#include<stdio.h>

void main() {

	for(int i=0; i<4; i++) {

		for(int j=0; j<4; j++) {

			printf("*\t");

		}

		printf("\n");

	}

}
/*
vivek@vivek-HIRAY:~/Core2Web-TREE-/Daily flash/DailyFlash_17July$ cc prog4.c 
vivek@vivek-HIRAY:~/Core2Web-TREE-/Daily flash/DailyFlash_17July$ ./a.out 
*	*	*	*	
*	*	*	*	
*	*	*	*	
*	*	*	*



*/
