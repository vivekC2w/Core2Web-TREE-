

#include<stdio.h>

void main() {

	for(int i=1; i<=5; i++) {

		for(int j=1; j<=5; j++) {

			printf("* ");

		}

		printf("\n");

	}

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Loops/forWhileDOWhileLoop/NestedFor18July$ cc prog1.c 
.vivek@vivek-HIRAY:~/PPA5/C/Loops/forWhileDOWhileLoop/NestedFor18July$ ./a.out 
* * * * * 
* * * * * 
* * * * * 
* * * * * 
* * * * * 
 */
