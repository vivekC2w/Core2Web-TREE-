#include<stdio.h>

void main() {

	int x = 10;
	int y = 15;

	int ans = 0;

	ans = x ^ y;

	printf("%d\n",ans);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/left_right_shiftopr/11jun$ cc xor.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/left_right_shiftopr/11jun$ ./a.out 
5
 */
