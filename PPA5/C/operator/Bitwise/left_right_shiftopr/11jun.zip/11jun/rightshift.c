#include<stdio.h>

void main() {

	int x = 35;
	int ans = 0;

	ans = x >> 3;

	printf("%d\n",ans);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun$ cc rightshift.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun$ ./a.out 
4
 */
