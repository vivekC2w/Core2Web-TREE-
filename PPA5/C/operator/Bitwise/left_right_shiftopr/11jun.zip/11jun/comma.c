#include<stdio.h>

void main() {

	int x = 10, 20, 30 ,40, 50;
	printf("%d\n",x);
	
	//int y = (10, 20, 30, 40, 50);
	//printf("%d\n",y);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/left_right_shiftopr/11jun$ cc comma.c 
comma.c: In function ‘main’:
comma.c:5:14: error: expected identifier or ‘(’ before numeric constant
    5 |  int x = 10, 20, 30 ,40, 50;
      |              ^~
 */
