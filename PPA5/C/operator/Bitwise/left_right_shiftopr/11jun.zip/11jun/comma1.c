#include<stdio.h>

void main() {

       // int x = 10, 20, 30 ,40, 50;
        //printf("%d\n",x);

        int y = (10, 20, 30, 40, 50);
        printf("%d\n",y);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/left_right_shiftopr/11jun$ cc comma1.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/left_right_shiftopr/11jun$ ./a.out 
50
 */
