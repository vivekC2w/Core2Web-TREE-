
#include<stdio.h>

void main() {

	int x = 15;
	int ans = 0;

	ans = x << 3;

	printf("%d\n",ans);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise$ cc prog2.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise$ ./a.out
120
 */
