#include<stdio.h>

void main() {

	int a = 48, b = 95;

	int ans = a + b;

	printf("%d\n",ans);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/24jun$ cc prog1.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/24jun$ ./a.out 
143
 */
