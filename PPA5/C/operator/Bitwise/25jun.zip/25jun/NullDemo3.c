

#include<stdio.h>

void main() {

        printf("Core2Web");
                ;;;;;;;

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/25jun$ cc NullDemo3.c
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/25jun$ ./a.out 
Core2Web
*/
