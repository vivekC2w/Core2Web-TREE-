

#include<stdio.h>

void main() {

        printf("Core2Web")

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/25jun$ cc NullDemo1.c
NullDemo1.c: In function ‘main’:
NullDemo1.c:7:27: error: expected ‘;’ before ‘}’ token
    7 |         printf("Core2Web")
      |                           ^
      |                           ;
    8 | 
    9 | }
      | ~                      
 */
