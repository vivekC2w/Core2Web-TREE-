
#include<stdio.h>

void main() {

	extern int a;
	
}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/25jun$ cc DeclarationDemo.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/25jun$ ./a.out 
 */
