

#include<stdio.h>

void main() {

	int a = 10;
	
	if(a != 10)			//False
		printf("Equal\n");
		printf("End of it\n");

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ cc ifDemo5.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ ./a.out
End of it
 */
