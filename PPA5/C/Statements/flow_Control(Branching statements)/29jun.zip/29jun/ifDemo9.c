

#include<stdio.h>

void main() {

	int marks = 89;

	if(marks > 90) 		//False
		
		printf("Laptop\n");
		printf("Bike\n");
		printf("Watch\n");

	
	printf("NewT-Shirts\n");

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ cc ifDemo9.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ ./a.out
Bike
Watch
NewT-Shirts
*/
