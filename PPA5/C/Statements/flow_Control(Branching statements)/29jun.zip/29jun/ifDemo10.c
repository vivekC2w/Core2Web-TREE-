

#include<stdio.h>

void main() {

	int marks = 89;

	if(marks > 90);{		//False  ';' =  Null Statement
		
		printf("Laptop\n");
		printf("Bike\n");
		printf("Watch\n");

	}
	printf("NewT-Shirts\n");

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ cc ifDemo10.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ ./a.out
Laptop
Bike
Watch
NewT-Shirts
*/
