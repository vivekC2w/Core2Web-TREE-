

#include<stdio.h>

void main() {

	int marks = 89;

	if(marks > 90) {		//True
		
		printf("Laptop\n");
		printf("Bike\n");
		printf("Watch\n");

	}
	printf("NewT-Shirts\n");

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ cc ifDemo8.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ ./a.out
NewT-Shirts
*/
