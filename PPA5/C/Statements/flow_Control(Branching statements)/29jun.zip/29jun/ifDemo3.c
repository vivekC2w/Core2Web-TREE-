

#include<stdio.h>

void main() {

	int a = 5;
	if(a < 10)		//False
		printf("a is smaller thean 10\n");

}

/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ cc ifDemo3.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ ./a.out
a is smaller thean 10
 */
