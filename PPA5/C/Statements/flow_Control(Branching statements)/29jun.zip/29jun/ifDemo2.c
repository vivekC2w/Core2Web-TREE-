

#include<stdio.h>

void main() {

	int a = 5;
	if(a > 10)		//False
		printf("a is greater thean 10");

}

/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ cc ifDemo2.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ ./a.out
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ 
 */
