

#include<stdio.h>

void main() {
	
	int marks = 93;

	//if(marks > 90) 
	if(marks < 90) 
		printf("Laptop\n");
		printf("Watch\n");
		printf("Bike\n");

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ cc ifDemo1.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ ./a.out
Laptop
Watch
Bike

vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ cc ifDemo1.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)$ ./a.out
Watch
Bike
*/
