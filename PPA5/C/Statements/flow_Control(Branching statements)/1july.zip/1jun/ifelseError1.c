
#include<stdio.h>

void main() {

	int a = 10;
	else {
		printf("Both are same\n");
	}

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/1jun$ cc ifelseError1.c 
ifelseError1.c: In function ‘main’:
ifelseError1.c:7:2: error: ‘else’ without a previous ‘if’
    7 |  else {
      |  ^~~~
 */
