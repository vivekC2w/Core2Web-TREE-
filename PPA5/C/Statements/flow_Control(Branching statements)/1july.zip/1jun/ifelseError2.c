
#include<stdio.h>

void main() {

	else if {
		printf("Both are same");
	}
}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/1jun$ cc ifelseError2.c
ifelseError2.c: In function ‘main’:
ifelseError2.c:6:2: error: ‘else’ without a previous ‘if’
    6 |  else if {
      |  ^~~~
ifelseError2.c:6:10: error: expected ‘(’ before ‘{’ token
    6 |  else if {
      |          ^
      |          (
 */
