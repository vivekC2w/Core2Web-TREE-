
#include<stdio.h>

void main() {

	int a = 20;
	if(a == 10) {

		printf("a is 10\n");

	}else if(a > 10) {

		printf("a is greater\n");

	}

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/1jun$ cc ifelseError3.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/1jun$ ./a.out 
a is greater
 */
