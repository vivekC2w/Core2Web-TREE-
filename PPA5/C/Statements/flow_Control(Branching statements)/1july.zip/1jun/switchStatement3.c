
#include<stdio.h>

void main() {

	int a = 2;
	switch(a) {		
		
		case 1:
			
			printf("Inside Switch\n");		//no error

	}
	printf("Outside Switch\n");

}

/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/1jun$ cc switchStatement3.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/1jun$ ./a.out 
Outside Switch
 */
