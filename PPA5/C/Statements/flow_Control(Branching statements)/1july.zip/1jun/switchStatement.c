#include<stdio.h>

void main() {

	switch() {    //without cases and expressions
			//Error	
	}

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/1jun$ cc switchStatement.c
switchStatement.c: In function ‘main’:
switchStatement.c:5:9: error: expected expression before ‘)’ token
    5 |  switch() {    //without cases and expressions
      |         ^
 */
