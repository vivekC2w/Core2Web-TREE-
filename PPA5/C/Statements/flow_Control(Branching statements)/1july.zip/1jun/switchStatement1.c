
#include<stdio.h>

void main() {

	int a = 1;
	switch(a) {		//without cases
				//no error

	}

}
