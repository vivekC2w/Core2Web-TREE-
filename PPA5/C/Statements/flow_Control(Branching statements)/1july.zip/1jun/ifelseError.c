
#include<stdio.h>

void main() {

	int a = 10;
	if(a==10)
		printf("Both are same\n");

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/1jun$ cc ifelseError.c 
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/1jun$ ./a.out 
Both are same
 */
