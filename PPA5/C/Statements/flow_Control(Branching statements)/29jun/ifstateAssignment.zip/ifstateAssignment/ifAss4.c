

#include<stdio.h>

void main() {

	int a = -1;

	if(~a)                		// if(0)  = False
		printf("Hello\n");    
	printf("Hii\n");
}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/29jun$ cc ifAss4.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/29jun$ ./a.out 
Hii
 */
