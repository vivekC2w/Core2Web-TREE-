

#include<stdio.h>

void main() {

	int num = 20;

	if(num>20){				//if(0)
						//if(false)
		printf("num is greater than 20");

	}
	printf("num :%d\n",num);

}

/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/30jun/ifelseStateAssign$ cc ifelse1.c 
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/30jun/ifelseStateAssign$ ./a.out 
num :20
 */
