
#include<stdio.h>

int main() {

	float x = 5.2f, y = 10.5f;

	if(x == 5.2f) {				//if(1)
						
		printf("x :%f\n",x);		//x :5.2

	}

	if(y == 10.5f); {			//if(1); Null Statement    

		printf("y :%f\n",y);		//y :10.5

	}

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/30jun/ifelseStateAssign$ cc ifelse5.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/30jun/ifelseStateAssign$ ./a.out 
x :5.200000
y :10.500000

 */
