

#include<stdio.h>

void main() {

	int a,b;

	printf("Enter Values of a and b:\n");
	scanf("%d %d",&a,&b);

	printf("a = %d\nb = %d\n",a,b);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/6july$ cc scanfDemo3.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/6july$ ./a.out 
Enter Values of a and b:
10
20
a = 10
b = 20
*/
