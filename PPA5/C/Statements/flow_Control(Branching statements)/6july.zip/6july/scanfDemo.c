

#include<stdio.h>

void main() {

	int a;

	printf("Value of a :%d\n",a);     //a = 0 Garbage_Value 

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/6july$ cc scanfDemo.c 
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/6july$ ./a.out 
Value of a :0
 */
