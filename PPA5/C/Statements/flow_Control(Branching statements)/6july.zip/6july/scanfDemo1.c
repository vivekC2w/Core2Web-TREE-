

#include<stdio.h>

void main() {

	int a;

	printf("Enter Number: \n");
	scanf("%d",&a);

	printf("Value of a : %d\n",a);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/6july$ cc scanfDemo1.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/6july$ ./a.out 
Enter Number: 
10       
Value of a : 10
 */
