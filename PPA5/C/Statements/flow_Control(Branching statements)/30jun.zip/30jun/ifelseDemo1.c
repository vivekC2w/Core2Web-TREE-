

#include<stdio.h>

void main() {

	int userName = 123;
	int password = 456;

	if(userName == 12 && password == 456) {

		printf("Successfully Login\n");

	}else {

		printf("Invalid UserName or password\n");

	}

	printf("Program completed\n");

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/30jun$ cc ifelseDemo1.c 
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/30jun$ ./a.out
Invalid UserName or password
Program completed
 */
