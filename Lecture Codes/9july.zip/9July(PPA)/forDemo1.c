

#include<stdio.h>

void main() {

	for(int i=1; i<=5; i++) {

		printf("%d\n",i);

	}

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Loops/forLoop/9July(PPA)$ cc forDemo1.c 
vivek@vivek-HIRAY:~/PPA5/C/Loops/forLoop/9July(PPA)$ ./a.out 
1
2
3
4
5
 */
