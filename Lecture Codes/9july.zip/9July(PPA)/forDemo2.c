

#include<stdio.h>

void main() {

	for(int i=5; i>=1; i--) {

		printf("%d\n",i);

	}

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Loops/forLoop/9July(PPA)$ cc forDemo2.c 
vivek@vivek-HIRAY:~/PPA5/C/Loops/forLoop/9July(PPA)$ ./a.out 
5
4
3
2
1
 */
