

#include<stdio.h>

void main() {

	int a,b;

	printf("Enter The value of a :\n");
	scanf("%d",&a);

	printf("Enter The value of b :\n");
	scanf("%d",&b);

	printf("a = %d\n",a);
	printf("b = %d\n",b);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/6july$ cc scanfDemo2.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/6july$ ./a.out 
Enter The value of a :
10
Enter The value of b :
20
a = 10
b = 20
*/

