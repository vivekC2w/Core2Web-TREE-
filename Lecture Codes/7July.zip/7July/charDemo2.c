

#include<stdio.h>

void main() {

	char ch1, ch2;

	printf("Enter Two Characters:\n");
	scanf("%c %c",&ch1, &ch2);

	printf("%c\n%c\n",ch1,ch2);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/scanf(ipFromUser)/7July$ cc charDemo2.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/scanf(ipFromUser)/7July$ ./a.out 
Enter Two Characters:
A   
Z
A
Z
 */
