

#include<stdio.h>

void main() {

	float val1, val2;

	printf("Enter Two Values For Float:\n");
	scanf("%f %f",&val1, &val2);

	printf("val1 = %f\n val2 = %f\n",val1,val2);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/scanf(ipFromUser)/7July$ cc floatDemo4.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/scanf(ipFromUser)/7July$ ./a.out 
Enter Two Values For Float:
20.5
39.65
val1 = 20.500000
 val2 = 39.650002
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/scanf(ipFromUser)/7July$ ./a.out 
Enter Two Values For Float:
65.6
89.3
val1 = 65.599998
 val2 = 89.300003
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/scanf(ipFromUser)/7July$ ./a.out 
Enter Two Values For Float:
75.5
98.10
val1 = 75.500000
 val2 = 98.099998
 */
