
#include<stdio.h>

void main() {

	int ans = 0;

	ans = 3 + 4 * 2;
	//  = 3 + 8
	//  = 11
	
	printf("%d\n",ans);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Incrementdec/4june$ cc prog4.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Incrementdec/4june$ ./a.out 
11
 */
