#include<stdio.h>

void main() {

        int ans = 0;

        ans = 8 + 4 / 2 - 5;
        //  = 8 + 2 - 5
	//  = 10 - 5
        //  = 5

        printf("%d\n",ans);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Incrementdec/4june$ cc prog5.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Incrementdec/4june$ ./a.out 
5
 */
