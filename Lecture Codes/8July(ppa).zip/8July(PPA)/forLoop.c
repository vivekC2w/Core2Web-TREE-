

#include<stdio.h>

void main() {

	for(int i = 1; i <= 10; i++) {

		printf("Core2Web\n");

	}

}
/*
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/scanf(ipFromUser)/8July(PPA)$ cc forLoop.c
vivek@vivek-HIRAY:~/PPA5/C/Statements/flow_Control(Branching statements)/scanf(ipFromUser)/8July(PPA)$ ./a.out 
Core2Web
Core2Web
Core2Web
Core2Web
Core2Web
Core2Web
Core2Web
Core2Web
Core2Web
Core2Web
 */
