#include<stdio.h>

void main() {

	int b = 16, ans = 0;
	ans = b << 3;
	printf("%d\n",ans);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun/practicecodes$ cc prog4.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun/practicecodes$ ./a.out
128
 */
