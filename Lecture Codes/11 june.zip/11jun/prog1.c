#include<stdio.h>

void main() {

	int a = 12, b = 16, ans = 0;
	ans = a & b;

	printf("%d\n",ans);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun/practicecodes$ cc prog1.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun/practicecodes$ ./a.out
0
 */
