#include<stdio.h>

void main() {

	int a = 12, ans = 0;
	ans = a << 4;
	printf("%d\n",ans);

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun/practicecodes$ cc prog3.c 
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun/practicecodes$ ./a.out
192
 */
