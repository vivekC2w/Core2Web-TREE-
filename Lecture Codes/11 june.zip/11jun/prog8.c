#include<stdio.h>

void main() {

        int a = 4, b = 7, ans = 0;
        ans = a || b;
        //  = 4 || 7
        //  = 1
        printf("%d\n",ans); // 1

}
/*
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun/practicecodes$ cc prog8.c
vivek@vivek-HIRAY:~/PPA5/C/operator/Bitwise/11jun/practicecodes$ ./a.out 
1
 */
